package com.futbol.tvargentina;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** API-Football fixtures + TheSportsDB Argentina TV listing + Android TV Remote v2. */
public class MainActivity extends Activity implements TvRemote.Listener {
    private static final int BG=0xff0b1424,CARD=0xff1c2c43,FG=0xfff5f7fb,DIM=0xffa8b9cf,ACCENT=0xff42c3fc,GOOD=0xff76d5a3;
    private static final String TV_PACKAGE="com.tedear.app";
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService pool=Executors.newSingleThreadExecutor();
    private final ArrayList<JSONObject> games=new ArrayList<>();
    private SharedPreferences sp;private TvRemote remote;
    private LinearLayout root,listing,remoteKeys;
    private TextView status,summary,modeLabel;
    private EditText apiField,ipField,pinField;
    private boolean confirmedOnly=true;
    private String pendingChannel="",recordingChannel=null;
    private final ArrayList<Integer> keyRecording=new ArrayList<>();
    private int alertMinutes=15;
    private boolean tvOpenPending=false;
    private final String[] channelNames={"ESPN PREMIUM","ESPN PREMIUM OP2","TNT SPORTS","TYC SPORTS","TYC INTERNACIONAL","ESPN","ESPN 2","ESPN 3","ESPN 4","ESPN 5","ESPN 6","ESPN 7","FOX SPORTS HD","FOX SPORTS 2 HD","FOX SPORTS 3 HD","FOX SPORTS PREMIUM","DEPORTV","AMERICA SPORTS","TUDN","BEIN SPORTS XTRA","BEIN SPORTS XTRA Ñ","LPFPLAY","OTRO CANAL"};
    private final DateTimeFormatter display=DateTimeFormatter.ofPattern("EEE dd/MM HH:mm",Locale.forLanguageTag("es-AR"));
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        sp=getSharedPreferences("futbol",MODE_PRIVATE);remote=new TvRemote(this,this);
        confirmedOnly=sp.getBoolean("confirmedOnly",true);alertMinutes=sp.getInt("minutes",15);
        readCache();buildUI();onNotification(getIntent());
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},240);
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);onNotification(intent);}
    private void onNotification(Intent intent){if(intent!=null&&"open_tv_from_reminder".equals(intent.getAction())){
        pendingChannel=intent.getStringExtra("channel");if(pendingChannel==null)pendingChannel="";
        tvOpenPending=true;ui.postDelayed(()->openTv(pendingChannel),400);
    }}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable background(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private EditText field(String hint,String value){EditText e=new EditText(this);e.setText(value);e.setHint(hint);e.setTextColor(FG);e.setHintTextColor(DIM);e.setSingleLine(true);e.setTextSize(14);e.setPadding(dp(10),dp(6),dp(10),dp(6));e.setBackground(background(0xff243950,10));return e;}
    private Button button(String label,Runnable action){Button b=new Button(this);b.setAllCaps(false);b.setText(label);b.setTextColor(FG);b.setTextSize(13);b.setPadding(dp(6),dp(5),dp(6),dp(5));b.setBackground(background(0xff2b4d6a,10));b.setOnClickListener(v->action.run());return b;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout section(String title){LinearLayout l=column();l.setPadding(dp(12),dp(12),dp(12),dp(12));l.setBackground(background(CARD,14));l.addView(text(title,17,FG,true));gap(l,8);root.addView(l,new LinearLayout.LayoutParams(-1,-2));gap(root,12);return l;}
    private void gap(LinearLayout l,int p){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(p)));}
    private void add(LinearLayout l,View v){l.addView(v,new LinearLayout.LayoutParams(-1,-2));}
    private void twin(LinearLayout l,View a,View b){LinearLayout r=horizontal();r.addView(a,new LinearLayout.LayoutParams(0,dp(44),1));View blank=new View(this);r.addView(blank,new LinearLayout.LayoutParams(dp(6),1));r.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));add(l,r);}
    private void info(String s){ui.post(()->{status.setText(s);Toast.makeText(this,s,Toast.LENGTH_SHORT).show();});}
    private void buildUI(){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);root=column();root.setPadding(dp(12),dp(14),dp(12),dp(20));scroll.addView(root);setContentView(scroll);
        add(root,text("⚽ FÚTBOL TV ARGENTINA",23,FG,true));gap(root,4);add(root,text("世界主流联赛 · 国家队 · 阿根廷电视台",12,DIM,false));gap(root,13);
        LinearLayout config=section("① 赛程 API（API-Football）");
        apiField=field("填写 API-Football 免费 API Key",sp.getString("apiKey",""));apiField.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);add(config,apiField);gap(config,6);
        twin(config,button("保存 Key",()->{sp.edit().putString("apiKey",apiField.getText().toString().trim()).apply();info("API Key 已保存在本机");}),button("刷新未来 7 天赛程",this::refresh));gap(config,6);
        add(config,text("免费计划目前为每天 100 次请求；一次刷新最多请求 7 天赛程及 7 天电视数据。频道信息有限，不能保证完整。",12,DIM,false));
        LinearLayout schedule=section("② 阿根廷电视转播比赛");
        LinearLayout tabs=horizontal();Button confirmed=button("只看已确认",()->{confirmedOnly=true;sp.edit().putBoolean("confirmedOnly",true).apply();render();});
        Button all=button("查看所有赛程",()->{confirmedOnly=false;sp.edit().putBoolean("confirmedOnly",false).apply();render();});
        tabs.addView(confirmed,new LinearLayout.LayoutParams(0,dp(42),1));tabs.addView(all,new LinearLayout.LayoutParams(0,dp(42),1));add(schedule,tabs);gap(schedule,8);
        summary=text("",13,DIM,false);add(schedule,summary);gap(schedule,8);listing=column();add(schedule,listing);gap(schedule,6);
        add(schedule,text("仅“已确认”比赛会显示具体频道。未能取得频道数据的场次显示待核实；也可手动确认。频道版权、节目安排随时可能变化。",12,DIM,false));
        LinearLayout reminders=section("③ 开赛提醒");
        add(reminders,text("选择提醒时间，然后对单场比赛点“提醒”。系统省电模式可能使提醒稍有延迟。",12,DIM,false));gap(reminders,6);
        Spinner spinner=new Spinner(this);String[] mins={"5 分钟前","15 分钟前","30 分钟前","60 分钟前"};ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,mins);spinner.setAdapter(adapter);
        spinner.setSelection(alertMinutes==5?0:alertMinutes==30?2:alertMinutes==60?3:1);
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){int[] choices={5,15,30,60};alertMinutes=choices[pos];sp.edit().putInt("minutes",alertMinutes).apply();ReminderReceiver.restore(MainActivity.this);}});add(reminders,spinner);
        LinearLayout tv=section("④ Google TV · TedeAr");
        ipField=field("Google TV 局域网 IP，例如 192.168.1.50",sp.getString("tvIp",""));add(tv,ipField);gap(tv,5);
        twin(tv,button("连接电视",this::connectTv),button("开始配对",this::startPair));gap(tv,5);
        pinField=field("电视上显示的 6 位配对码","");add(tv,pinField);gap(tv,5);
        twin(tv,button("确认配对码",this::finishPair),button("打开电视 TedeAr",()->openTv("")));gap(tv,7);
        status=text("电视未连接 · 无法在手机上验证 TedeAr 的切台效果",12,DIM,false);add(tv,status);gap(tv,8);
        twin(tv,button("切台录制 / 保存",this::recordDialog),button("终止录制",()->{recordingChannel=null;keyRecording.clear();info("已停止录制");}));gap(tv,7);
        add(tv,text("如果电视上的 TedeAr 不能被外部直接打开频道，请先录制对应频道的按键导航路径。",12,DIM,false));gap(tv,8);
        remoteKeys=column();add(tv,remoteKeys);addRemoteKeys();
        LinearLayout foot=section("⑤ 数据说明与手动补充");
        add(foot,text("API-Football 负责足球赛程；TheSportsDB 免费 TV 接口只提供少量记录。没有查到频道 ≠ 阿根廷没有转播。此 App 不提供直播或绕过付费验证。",12,DIM,false));gap(foot,6);
        add(foot,button("手动添加 / 修正比赛",this::addManualGame));
        render();
    }
    private void addRemoteKeys(){
        LinearLayout r=horizontal();r.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
        r.addView(button("▲",()->key(19)),new LinearLayout.LayoutParams(0,dp(44),1));r.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));add(remoteKeys,r);
        r=horizontal();r.addView(button("◀",()->key(21)),new LinearLayout.LayoutParams(0,dp(44),1));
        r.addView(button("确定",()->key(23)),new LinearLayout.LayoutParams(0,dp(44),1));r.addView(button("▶",()->key(22)),new LinearLayout.LayoutParams(0,dp(44),1));add(remoteKeys,r);
        r=horizontal();r.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));r.addView(button("▼",()->key(20)),new LinearLayout.LayoutParams(0,dp(44),1));r.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));add(remoteKeys,r);
        twin(remoteKeys,button("返回",()->key(4)),button("主页",()->key(3)));
    }
    private void key(int code){if(recordingChannel!=null)keyRecording.add(code);pool.execute(()->{try{remote.press(code);}catch(Exception e){info("遥控未连接："+e.getMessage());}});}
    private void recordDialog(){if(recordingChannel!=null){new AlertDialog.Builder(this).setTitle("保存录制").setMessage("当前频道："+recordingChannel+"；已记录 "+keyRecording.size()+" 个按键").setPositiveButton("保存当前录制",(d,w)->saveRecorded()).setNegativeButton("继续录制",null).show();return;}new AlertDialog.Builder(this).setTitle("录制频道导航").setItems(channelNames,(d,which)->{
        String chosen=channelNames[which];if("OTRO CANAL".equals(chosen)){EditText e=field("输入频道名称","");new AlertDialog.Builder(this).setTitle("频道名称").setView(e).setPositiveButton("开始录制",(dd,w)->startRecording(e.getText().toString())).show();}
        else startRecording(chosen);
    }).setNegativeButton("取消",null).show();}
    private void startRecording(String channel){recordingChannel=channel.trim();keyRecording.clear();
        if(recordingChannel.isEmpty())return;
        new AlertDialog.Builder(this).setTitle("录制 "+recordingChannel)
            .setMessage("先手动打开电视中的 TedeAr，使用本 App 下面的方向键/确认键进入频道。录完后再次点击“切台录制 / 保存”，选择“保存当前录制”。")
            .setPositiveButton("知道了",(d,w)->info("录制中："+recordingChannel)).show();}
    private void saveRecorded(){if(recordingChannel==null)return;JSONArray a=new JSONArray();for(int v:keyRecording)a.put(v);
        sp.edit().putString("macro:"+norm(recordingChannel),a.toString()).apply();
        info("已保存 "+recordingChannel+" 的 "+a.length()+" 个遥控按键");recordingChannel=null;keyRecording.clear();}
    private void connectTv(){String ip=ipField.getText().toString().trim();if(ip.isEmpty()){info("先填写 Google TV IP");return;}
        sp.edit().putString("tvIp",ip).apply();pool.execute(()->{try{remote.openRemote(ip);}catch(Exception e){info("连接失败，请先配对或检查 IP："+e.getMessage());}});}
    private void startPair(){String ip=ipField.getText().toString().trim();if(ip.isEmpty()){info("先填写电视 IP");return;}
        sp.edit().putString("tvIp",ip).apply();pool.execute(()->{try{remote.startPair(ip);}catch(Exception e){info("配对连接失败："+e.getMessage());}});}
    private void finishPair(){String code=pinField.getText().toString().trim();pool.execute(()->{try{remote.completePair(code);remote.openRemote(sp.getString("tvIp",""));}catch(Exception e){info("配对失败："+e.getMessage());}});}
    private void openTv(String chan){pendingChannel=chan==null?"":chan;
        if(!remote.isReady()){tvOpenPending=true;connectTv();return;}
        tvOpenPending=false;final String targetChannel=pendingChannel;pool.execute(()->{try{
            remote.launch(sp.getBoolean("marketLaunch",false)?"market://launch?id="+TV_PACKAGE:"android-app://"+TV_PACKAGE);
            String macro=sp.getString("macro:"+norm(targetChannel),"");JSONArray actions;
            try{actions=new JSONArray(macro);}catch(Exception e){actions=new JSONArray();}
            if(actions.length()>0){Thread.sleep(3800);for(int i=0;i<actions.length();i++){remote.press(actions.getInt(i));Thread.sleep(450);}}
            info("已发送 TedeAr 启动"+(actions.length()>0?"及录制的频道按键":"")+"指令，电视实际播放情况需要现场确认");
        }catch(Exception e){info("打开 TedeAr 失败："+e.getMessage());}});
    }
    private void refresh(){String key=apiField.getText().toString().trim();if(key.isEmpty()){info("请先填写 API-Football 的 API Key");return;}
        sp.edit().putString("apiKey",key).apply();summary.setText("正在读取未来 7 天的赛程和阿根廷频道数据…");
        pool.execute(()->{
            try {
                HashMap<String,JSONObject> old=new HashMap<>();synchronized(games){for(JSONObject item:games)old.put(item.optString("id"),item);}
                ArrayList<JSONObject> fresh=new ArrayList<>();ArrayList<JSONObject> tvListings=new ArrayList<>();
                LocalDate today=LocalDate.now(ZoneId.of("America/Argentina/Buenos_Aires"));
                for(int offset=0;offset<7;offset++){
                    String day=today.plusDays(offset).toString();
                    JSONObject fixtures=fetchJson("https://v3.football.api-sports.io/fixtures?date="+day+"&timezone=America%2FArgentina%2FBuenos_Aires",key);
                    JSONArray array=fixtures.optJSONArray("response");if(array!=null)for(int j=0;j<array.length();j++){
                        JSONObject entry=array.optJSONObject(j);if(entry==null)continue;
                        JSONObject league=entry.optJSONObject("league"),fixture=entry.optJSONObject("fixture"),teams=entry.optJSONObject("teams");
                        if(league==null||fixture==null||teams==null)continue;
                        JSONObject h=teams.optJSONObject("home"),a=teams.optJSONObject("away");if(h==null||a==null)continue;
                        String competition=league.optString("name"),country=league.optString("country");String home=h.optString("name"),away=a.optString("name");
                        if(!major(competition,country,home,away))continue;
                        long kickoff;try{kickoff=OffsetDateTime.parse(fixture.getString("date")).toInstant().toEpochMilli();}catch(Exception e){continue;}
                        if(kickoff<System.currentTimeMillis()-7200000L)continue;
                        JSONObject m=new JSONObject();m.put("id",String.valueOf(fixture.getLong("id")));m.put("league",competition);m.put("home",home);m.put("away",away);m.put("kickoff",kickoff);m.put("channel","");m.put("source","");
                        JSONObject prev=old.get(m.optString("id"));if(prev!=null){m.put("remind",prev.optBoolean("remind"));
                            if("manual".equals(prev.optString("source"))){m.put("channel",prev.optString("channel"));m.put("source","manual");}}
                        fresh.add(m);
                    }
                    try{JSONObject listing=fetchJson("https://www.thesportsdb.com/api/v1/json/123/eventstv.php?d="+day+"&a=Argentina&s=Soccer",null);
                        JSONArray tv=listing.optJSONArray("tvevent");if(tv!=null)for(int j=0;j<tv.length();j++){JSONObject t=tv.optJSONObject(j);if(t!=null)tvListings.add(t);}}
                    catch(Exception ignored){} // Free TV listings may not cover a date.
                }
                for(JSONObject item:fresh)if(!"manual".equals(item.optString("source")))for(JSONObject tv:tvListings){
                    if(!"Argentina".equalsIgnoreCase(tv.optString("strCountry")))continue;
                    String tvChannel=tv.optString("strChannel");
                    if(tvChannel.isEmpty()||!matchTvEvent(item,tv))continue;
                    item.put("channel",tvChannel);item.put("source","tvapi");break;
                }
                fresh.sort(Comparator.comparingLong(x->x.optLong("kickoff")));
                synchronized(games){games.clear();games.addAll(fresh);}writeCache();
                for(JSONObject m:fresh)if(m.optBoolean("remind"))ReminderReceiver.schedule(this,m,alertMinutes);
                ui.post(()->{render();info("已更新 "+fresh.size()+" 场主流赛事；转播频道以已验证结果为准");});
            }catch(Exception e){info("刷新失败："+e.getMessage());}
        });
    }
    private JSONObject fetchJson(String address,String apiKey) throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(16000);
        c.setRequestProperty("Accept","application/json");if(apiKey!=null)c.setRequestProperty("x-apisports-key",apiKey);
        try{int status=c.getResponseCode();if(status!=200)throw new IOException("API HTTP "+status);
            try(InputStream stream=c.getInputStream()){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;
                while((n=stream.read(b))!=-1){out.write(b,0,n);if(out.size()>6*1024*1024)throw new IOException("数据过大");}
                JSONObject obj=new JSONObject(out.toString(StandardCharsets.UTF_8.name()));
                if(apiKey!=null&&obj.optJSONObject("errors")!=null&&obj.optJSONObject("errors").length()>0)throw new IOException("API-Football Key、额度或日期不可用："+obj.getJSONObject("errors").toString());
                return obj;}
        }finally{c.disconnect();}}
    private boolean major(String competition,String country,String h,String a){String s=norm(competition),c=norm(country);String t=norm(h)+" "+norm(a);
        if((s.contains("friendlies")||s.contains("amistoso"))&&!t.contains("argentina"))return false;
        String[] words={"premier league","primera division","liga profesional","primera nacional","copa argentina","la liga","laliga","serie a","bundesliga","ligue 1","eredivisie","primeira liga","liga portugal","major league soccer","mls","fa cup","copa del rey","brasileirao","champions league","europa league","conference league","libertadores","sudamericana","copa america","world cup","world championship","copa del mundo","euro championship","european championship","nations league","gold cup","africa cup of nations","friendlies","amistoso","qualification","eliminatoria"};
        for(String w:words)if(s.contains(w)){
            if(s.equals("serie a")&&!c.equals("brazil")&&!c.equals("italy"))return false;
            return true;}
        return false;
    }
    private static String norm(String s){if(s==null)return "";String n=Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT);return n.replaceAll("[^a-z0-9]+"," ").trim();}
    private boolean matchTvEvent(JSONObject game,JSONObject tv){try{
        String d=Instant.ofEpochMilli(game.getLong("kickoff")).atZone(ZoneId.of("America/Argentina/Buenos_Aires")).toLocalDate().toString();
        if(!d.equals(tv.optString("dateEvent")))return false;
        String name=" "+norm(tv.optString("strEvent"))+" ",h=norm(game.optString("home")),a=norm(game.optString("away"));
        return h.length()>=4&&a.length()>=4&&name.contains(" "+h+" ")&&name.contains(" "+a+" ");
    }catch(Exception e){return false;}}
    private void readCache(){try{JSONArray a=new JSONArray(sp.getString("games","[]"));synchronized(games){games.clear();for(int i=0;i<a.length();i++)games.add(a.getJSONObject(i));}}catch(Exception ignored){}}
    private void writeCache(){JSONArray a=new JSONArray();synchronized(games){for(JSONObject m:games)a.put(m);}sp.edit().putString("games",a.toString()).apply();}
    private void render(){if(listing==null)return;listing.removeAllViews();ArrayList<JSONObject> snapshot; synchronized(games){snapshot=new ArrayList<>(games);}
        int verified=0,reminders=0;for(JSONObject m:snapshot){if(!m.optString("channel").isEmpty())verified++;if(m.optBoolean("remind"))reminders++;}
        summary.setText((confirmedOnly?"已确认频道":"全部主流赛程")+" · "+verified+" 场有频道信息 / "+snapshot.size()+" 场赛事 · "+reminders+" 个已提醒");
        int shown=0;for(JSONObject game:snapshot){if(confirmedOnly&&game.optString("channel").isEmpty())continue;
            shown++;LinearLayout box=column();box.setPadding(dp(9),dp(10),dp(9),dp(10));box.setBackground(background(0xff263950,10));
            long kick=game.optLong("kickoff");String when=Instant.ofEpochMilli(kick).atZone(ZoneId.of("America/Argentina/Buenos_Aires")).format(display);
            add(box,text(when+"  ·  "+game.optString("league"),12,ACCENT,false));gap(box,3);
            add(box,text(game.optString("home")+"  vs  "+game.optString("away"),16,FG,true));gap(box,4);
            String channel=game.optString("channel");String label=channel.isEmpty()?"转播待核实":"🇦🇷 "+channel+("manual".equals(game.optString("source"))?"（手动确认）":"（电视数据）");
            add(box,text(label,13,channel.isEmpty()?DIM:GOOD,true));gap(box,7);
            LinearLayout controls=horizontal();Button remind=button(game.optBoolean("remind")?"取消提醒":"提醒",()->toggleRemind(game));
            Button choose=button("确认频道",()->chooseChannel(game));Button launch=button("打开 TV",()->openTv(game.optString("channel")));
            controls.addView(remind,new LinearLayout.LayoutParams(0,dp(40),1));controls.addView(choose,new LinearLayout.LayoutParams(0,dp(40),1));controls.addView(launch,new LinearLayout.LayoutParams(0,dp(40),1));add(box,controls);add(listing,box);gap(listing,8);
        }
        if(shown==0)add(listing,text(snapshot.isEmpty()?"暂无赛程：填写 API-Football Key 后点击刷新。":"当前没有获得已确认阿根廷转播频道的场次。免费电视数据不完整；可切换“查看所有赛程”并手动确认频道。",13,DIM,false));
    }
    private void toggleRemind(JSONObject m){boolean newState=!m.optBoolean("remind");try{m.put("remind",newState);writeCache();if(newState)ReminderReceiver.schedule(this,m,alertMinutes);else ReminderReceiver.cancel(this,m.optString("id"));render();}catch(Exception e){info(e.getMessage());}}
    private void chooseChannel(JSONObject m){new AlertDialog.Builder(this).setTitle("确认这场比赛在阿根廷的频道")
        .setItems(channelNames,(d,which)->{String ch=channelNames[which];if("OTRO CANAL".equals(ch)){EditText edit=field("输入确认的频道名称","");new AlertDialog.Builder(this).setView(edit).setPositiveButton("保存",(di,w)->saveChannel(m,edit.getText().toString())).show();}
            else saveChannel(m,ch);}).setNeutralButton("清除频道",(d,w)->saveChannel(m,"")).setNegativeButton("取消",null).show();}
    private void saveChannel(JSONObject m,String ch){try{m.put("channel",ch.trim());m.put("source",ch.trim().isEmpty()?"":"manual");writeCache();render();}catch(Exception e){info(e.getMessage());}}
    private void addManualGame(){LinearLayout form=column();form.setPadding(dp(15),dp(5),dp(15),dp(5));
        EditText home=field("主队", ""),away=field("客队", ""),league=field("赛事，例如 Copa Argentina", ""),date=field("阿根廷时间 yyyy-MM-dd HH:mm","");
        add(form,home);add(form,away);add(form,league);add(form,date);
        new AlertDialog.Builder(this).setTitle("手动添加比赛（官方赛程核对后使用）").setView(form).setPositiveButton("保存",(d,w)->{
            try{LocalDateTime dt=LocalDateTime.parse(date.getText().toString(),DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));long ts=dt.atZone(ZoneId.of("America/Argentina/Buenos_Aires")).toInstant().toEpochMilli();
                JSONObject m=new JSONObject();m.put("id","manual-"+ts+"-"+home.getText());m.put("home",home.getText().toString());m.put("away",away.getText().toString());m.put("league",league.getText().toString());m.put("kickoff",ts);m.put("channel","");m.put("source","");m.put("remind",false);
                synchronized(games){games.add(m);games.sort(Comparator.comparingLong(x->x.optLong("kickoff")));}writeCache();render();
            }catch(Exception ex){info("日期格式错误，请用 yyyy-MM-dd HH:mm");}
        }).setNegativeButton("取消",null).show();}
    @Override public void status(String value){info(value);}
    @Override public void pairingCodeReady(){info("请查看电视并输入 6 位配对码");}
    @Override public void pairingSucceeded(){info("Google TV 配对成功");}
    @Override public void connected(){info("Google TV 已连接");if(tvOpenPending)ui.post(()->openTv(pendingChannel));}
    @Override public void disconnected(String problem){info(problem);}
    @Override protected void onDestroy(){super.onDestroy();remote.closePair();remote.closeControl();pool.shutdownNow();}
}
