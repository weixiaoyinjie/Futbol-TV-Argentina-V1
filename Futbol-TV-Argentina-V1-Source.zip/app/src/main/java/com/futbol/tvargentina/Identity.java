package com.futbol.tvargentina;

import android.content.Context;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Date;

/** Stable self-signed client certificate; losing it requires re-pairing. */
public final class Identity {
    private static final String ALIAS="sports-remote";
    private static final char[] PASS="local-pairing-credential".toCharArray();
    public final KeyStore store;
    public final X509Certificate certificate;
    private Identity(KeyStore store,X509Certificate certificate){this.store=store;this.certificate=certificate;}

    public static synchronized Identity load(Context context) throws Exception {
        File file=new File(context.getFilesDir(),"tv-identity.p12");
        KeyStore ks=KeyStore.getInstance("PKCS12");
        if(file.isFile()) {
            try(FileInputStream in=new FileInputStream(file)){ks.load(in,PASS);}
            return new Identity(ks,(X509Certificate)ks.getCertificate(ALIAS));
        }
        KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");gen.initialize(2048);
        KeyPair pair=gen.generateKeyPair();
        X500Name dn=new X500Name("CN=TedeAr-Sports-Remote");
        long now=System.currentTimeMillis();
        JcaX509v3CertificateBuilder builder=new JcaX509v3CertificateBuilder(
            dn,BigInteger.valueOf(now),new Date(now-86400000L),
            new Date(now+10L*365*86400000L),dn,pair.getPublic());
        X509Certificate cert=new JcaX509CertificateConverter().getCertificate(
            builder.build(new JcaContentSignerBuilder("SHA256withRSA").build(pair.getPrivate())));
        ks.load(null,PASS);
        ks.setKeyEntry(ALIAS,pair.getPrivate(),PASS,new Certificate[]{cert});
        try(FileOutputStream out=new FileOutputStream(file)){ks.store(out,PASS);}
        return new Identity(ks,cert);
    }
    public static char[] password(){return PASS;}
}
