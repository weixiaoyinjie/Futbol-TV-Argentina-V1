package com.futbol.tvargentina;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    static final String CHANNEL="football_schedule";
    public static void schedule(Context c, JSONObject game, int mins){
        try {
            long kickoff=game.getLong("kickoff");
            long remind=kickoff-mins*60000L;
            if(remind<System.currentTimeMillis())return;
            int id=game.getString("id").hashCode();
            Intent intent=new Intent(c,ReminderReceiver.class).setAction("match:"+id);
            intent.putExtra("id",game.getString("id"));
            intent.putExtra("home",game.optString("home"));
            intent.putExtra("away",game.optString("away"));
            intent.putExtra("channel",game.optString("channel"));
            PendingIntent pi=PendingIntent.getBroadcast(c,id,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            AlarmManager alarm=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            if(alarm!=null)alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,remind,pi);
        } catch(Exception ignored){}
    }
    public static void cancel(Context c,String id){
        Intent intent=new Intent(c,ReminderReceiver.class).setAction("match:"+id.hashCode());
        PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),intent,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
        if(pi!=null){((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pi);pi.cancel();}
    }
    @Override public void onReceive(Context c,Intent alarm){
        String home=alarm.getStringExtra("home"),away=alarm.getStringExtra("away"),channel=alarm.getStringExtra("channel");
        Intent open=new Intent(c,MainActivity.class).setAction("open_tv_from_reminder")
            .putExtra("id",alarm.getStringExtra("id")).putExtra("channel",channel)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent click=PendingIntent.getActivity(c,alarm.getStringExtra("id").hashCode(),open,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"足球开赛提醒",NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder builder=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
        String title="⚽ 即将开赛："+home+" vs "+away;
        String desc=channel==null||channel.isEmpty()?"点击打开 TedeAr（转播频道待确认）":"阿根廷频道："+channel+" · 点击打开电视 TedeAr";
        Notification note=builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(desc)
            .setContentIntent(click).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).build();
        try{nm.notify(alarm.getStringExtra("id").hashCode(),note);}catch(SecurityException ignored){}
    }
    public static void restore(Context c){
        SharedPreferences sp=c.getSharedPreferences("futbol",0);
        int mins=sp.getInt("minutes",15);
        try{JSONArray a=new JSONArray(sp.getString("games","[]"));for(int i=0;i<a.length();i++){
            JSONObject item=a.getJSONObject(i);if(item.optBoolean("remind"))schedule(c,item,mins);
        }}catch(Exception ignored){}
    }
}
