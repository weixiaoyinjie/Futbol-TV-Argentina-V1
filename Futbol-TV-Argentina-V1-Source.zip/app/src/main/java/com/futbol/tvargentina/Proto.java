package com.futbol.tvargentina;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** Minimal protobuf wire types 0 and 2, with robust varint frame delimiters. */
public final class Proto {
    private Proto() {}

    public static class Writer {
        private final ByteArrayOutputStream data = new ByteArrayOutputStream();
        public Writer num(int field, long value) {
            writeVarint(data, field * 8L);
            writeVarint(data, value);
            return this;
        }
        public Writer bytes(int field, byte[] value) {
            writeVarint(data, field * 8L + 2);
            writeVarint(data, value.length);
            data.write(value, 0, value.length);
            return this;
        }
        public Writer string(int field, String value) {
            return bytes(field, value.getBytes(StandardCharsets.UTF_8));
        }
        public Writer child(int field, Writer child) { return bytes(field, child.build()); }
        public byte[] build() { return data.toByteArray(); }
    }

    public static class Fields {
        private final Map<Integer, Object> items = new HashMap<>();
        public boolean has(int f) { return items.containsKey(f); }
        public long num(int f) { Object n = items.get(f); return n instanceof Long ? (Long)n : 0L; }
        public byte[] bytes(int f) { Object b=items.get(f); return b instanceof byte[] ? (byte[])b : null; }
        public Fields child(int f) throws IOException { byte[] b=bytes(f); return b == null ? new Fields() : parse(b); }
    }

    public static Fields parse(byte[] data) throws IOException {
        Fields result = new Fields();
        int[] pos = {0};
        while (pos[0] < data.length) {
            long tag = readVarint(data, pos);
            int wire = (int)(tag & 7); int field=(int)(tag >>> 3);
            if (field <= 0) throw new IOException("Invalid protobuf field");
            if (wire == 0) result.items.put(field, readVarint(data, pos));
            else if (wire == 2) {
                long len=readVarint(data,pos);
                if (len < 0 || len > data.length - pos[0]) throw new IOException("Bad protobuf length");
                byte[] b=new byte[(int)len];
                System.arraycopy(data,pos[0],b,0,(int)len); pos[0]+=(int)len;
                result.items.put(field,b);
            } else if (wire == 1 || wire == 5) {
                int step=wire==1?8:4;
                if (step>data.length-pos[0]) throw new IOException("Truncated protobuf field");
                pos[0]+=step;
            } else throw new IOException("Unsupported wire type "+wire);
        }
        return result;
    }

    private static long readVarint(byte[] data, int[] pos) throws IOException {
        long result=0;
        for(int shift=0;shift<70;shift+=7) {
            if (pos[0]>=data.length) throw new EOFException("Truncated varint");
            int c=data[pos[0]++] & 255;
            result|=(long)(c&127)<<shift;
            if((c&128)==0) return result;
        }
        throw new IOException("Varint too long");
    }

    private static long readVarint(InputStream in) throws IOException {
        long result=0;
        for(int shift=0;shift<70;shift+=7) {
            int c=in.read();
            if(c==-1) throw new EOFException("TV closed connection");
            result|=(long)(c&127)<<shift;
            if((c&128)==0)return result;
        }
        throw new IOException("Frame length varint too long");
    }

    private static void writeVarint(OutputStream out,long value) {
        try {
            while(true) {
                int c=(int)(value & 127);
                value >>>= 7;
                if(value==0) {out.write(c);return;}
                out.write(c|128);
            }
        } catch(IOException e) { throw new IllegalStateException(e); }
    }

    public static byte[] read(InputStream in) throws IOException {
        long len=readVarint(in);
        if(len < 0 || len > 1024*1024) throw new IOException("Unexpected TV packet size: "+len);
        byte[] b=new byte[(int)len];
        int offset=0;
        while(offset < b.length) {
            int n=in.read(b,offset,b.length-offset);
            if(n<0) throw new EOFException("TV closed packet mid-frame");
            offset+=n;
        }
        return b;
    }

    public static void write(OutputStream out, byte[] msg) throws IOException {
        writeVarint(out,msg.length);out.write(msg);out.flush();
    }
}
