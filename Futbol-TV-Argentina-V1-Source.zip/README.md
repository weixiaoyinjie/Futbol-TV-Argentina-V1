# Fútbol TV Argentina V1.0

**安卓手机 App（不是 Google TV 端安装包）**：全球主流俱乐部联赛、洲际比赛、国家队赛程；阿根廷地区电视转播频道匹配；单场开赛提醒；点击通知启动 Google TV 上的 TedeAr。

## 数据真实性和限制

- 足球赛程：API-Football v3，必须自行申请并填入 API Key。免费计划官方标示为每日 100 次请求。每次“刷新未来 7 天”大约调用 7 次该 API；不做后台自动抓取以控制额度。若比赛尚未被官方安排或 API 免费计划没有该赛季，则可能缺场次。
- 转播信息：TheSportsDB v1 的电视节目安排（以 `a=Argentina`、`s=Soccer` 获取），免费 Key `123`，其 `eventstv` 免费额度非常低：每次仅返回极少记录。只有同一天的双方球队名称均匹配、频道所属国家等于 Argentina 时才自动标记为有频道信息。**未标记不代表阿根廷没直播**。
- 赛程与转播数据来自两个不同的提供方，并不保证每一场都有完整或准确的转播信息。频道可按阿根廷转播指南人工核对后标记。人工确认标注为“手动确认”。
- TedeAr 不提供经过验证的公开频道跳转接口。本 App 只负责打开它，或者重放**用户自己录制的方向键导航步骤**，不会直接访问频道流地址。Google TV 配对/启动/切台必须实际测试。
- 提醒使用 Android AlarmManager `setAndAllowWhileIdle`，不会保证秒级准确，省电限制可能延迟。赛程刷新后缓存的比赛会安排提醒；必须对比赛手动选择“提醒”。手机重启会恢复仍在未来的已设置提醒。
- 本 App 不提供直播视频、不绕开任何账号、DRM 或订阅验证。

## 功能

1. 填入 API-Football Key，刷新未来 7 天的世界主流足球赛事；默认是阿根廷频道已确认筛选，可切换完整赛程。
2. 查看赛事日期、球队、阿根廷频道。对任何比赛可人工标记频道或取消频道。
3. 每场比赛可开启/关闭 5、15、30、60 分钟前通知。
4. 手机与 Google TV 同一 LAN，输入 Google TV IP，进行 Android TV Remote v2 配对（TCP 6467）和连接（TCP 6466）。
5. 点击通知或者比赛“打开 TV”后尝试启动 `com.tedear.app`；如已录制对应频道按键，则按顺序执行切台。
6. 电视的 TedeAr 频道没有外部跳转 API，录制前可先用程序内的方向键手动导航。
7. 没有 API Key 时可手动添加赛程，仅用于自己确认过的场次。

## GitHub Actions 编译（ZIP 不用先解压）

1. 在 GitHub 建新仓库 `Futbol-TV-Argentina-V1`。
2. 仓库根目录上传 `Futbol-TV-Argentina-V1-Source.zip` **保持 ZIP 原名，不要改成别的名字**。
3. 创建 `.github/workflows/android.yml`，内容用提供的 `GITHUB-ACTIONS-FUTBOL-V1.txt`。其脚本会先解压 ZIP 再编译。
4. Actions → `Build Futbol TV Argentina APK` → 运行或等待 push 自动运行，成功后从 Artifacts 下载 `Futbol-TV-Argentina-V1-APK`。

文件中已经包含 `.github/workflows/android.yml`，如果你把 ZIP 解压后直接上传整个 Android 项目，那么也可以省略第 3 步。

## 官方资料

- https://www.api-football.com/ （免费计划、API Key）
- https://www.api-football.com/documentation_v3 （赛程参数）
- https://www.thesportsdb.com/docs/api （电视节目安排）
- https://www.ligaprofesional.ar/ （阿根廷职业联赛官方转播公告）

注意：源码经过基本语法/结构审查，但当前容器无 Android SDK，**未在此完成 Gradle APK 构建或设备现场测试**。
